from django.db import models

# Create your models here.

class StaffMaster(models.Model):
    staffid=models.IntegerField()
    staffname=models.CharField(max_length=15)
    collegename=models.CharField(max_length=30)
    Department=models.CharField(max_length=20)
    Designation=models.CharField(max_length=10)
    def __str__(self):
        return self.StaffMaster
    























