from django.urls import path
from django.contrib.auth import views as auth_views
from . import views

urlpatterns = [
    path('login/', views.user_login, name='login'),
    path('signup/', views.user_signup, name='signup'),
    path('logout/', views.user_logout, name='logout'),
    
    path('homeDisplay/', views.homeDisplay, name='homeDisplay'),
    # Password reset URLs
    path('password_reset/', auth_views.PasswordResetView.as_view(), name='password_reset'),
    path('password_reset/done/', auth_views.PasswordResetDoneView.as_view(), name='password_reset_done'),
    path('reset/<uidb64>/<token>/', auth_views.PasswordResetConfirmView.as_view(), name='password_reset_confirm'),
    path('reset/done/', auth_views.PasswordResetCompleteView.as_view(), name='password_reset_complete'),
    

    path('insert_view/',views.insert_view,name='insert_view'),
    path('displayStaffInput/',views.displayStaffInput,name='display_StaffInput'),
    path('process_staff_entry/',views.process_Staff_entry,name='process_Staff_entry'),


    path('delete_Staff/',views.delete_Staff,name='delete_Staff'),

    path('search/', views.search_view, name='search'),
    
    


    path('edit_staff/int:pk/', views.edit_staff, name='edit_staff'),
    path('staff_detail/int:pk/', views.staff_detail, name='staff_detail'),
    path('Staffmaster_details/',views.Staffmaster_details ,name='Staffmaster_details'),
    ]


