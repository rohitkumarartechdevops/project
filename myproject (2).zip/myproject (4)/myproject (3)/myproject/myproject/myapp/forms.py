from django import forms 
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import *
from . models import StaffMaster

class StaffForm(forms.ModelForm):
    class Meta:
        model=StaffMaster
        fields='__all__'


class SignupForm(UserCreationForm):
    class Meta:
        model = User 
        fields = ['username', 'password1', 'password2']

class LoginForm(forms.Form):
    username = forms.CharField()
    password = forms.CharField(widget=forms.PasswordInput)
def clean(self):
    super(LoginForm,self).clean()
    username = self.cleaned_data.get('username')  
    password = self.cleaned_data.get('password')
    if len(username) < 5:
        self._errors['username'] = self.error_class(['A minimum of 5 characters is required'])
        for i in username:
            if i not in 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz':
                self._errors['username'] = self.error_class(['Username should only contain alphabets'])
    
    if len(password) != 8:
        self.add_error('password', 'Password length should be exactly 8 characters')
        for i in password:
            if i not in 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789@#$&*!':
                self._errors['password'] = self.error_class(['Password length should be exactly 8 characters'])
    return self.cleaned_data