from django.shortcuts import render, HttpResponse, get_object_or_404, redirect
from django.contrib.auth import authenticate, login, logout 
from .forms import SignupForm, LoginForm
from django . contrib.auth.decorators import login_required
from django.contrib import messages
from . forms import StaffForm
from . models import StaffMaster
from django . template import loader
from django . http import HttpResponse
# Create your views here.
# Home page


# signup page
def user_signup(request):
    if request.method == 'POST':
        form = SignupForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('login')
    else:
        form = SignupForm()
    return render(request, 'signup.html', {'form': form})

# login page
def user_login(request):
    if request.method == 'POST':
        form = LoginForm(request.POST)
        if form.is_valid():
            username = form.cleaned_data['username']
            password = form.cleaned_data['password']
            user = authenticate(request, username=username, password=password)
            if user:
                login(request, user)    
                return redirect('homeDisplay')
    else:
        form = LoginForm()
    return render(request, 'login.html', {'form': form})

# logout page
def user_logout(request):
    logout(request)
    return redirect('login')
@login_required
def homeDisplay(request):
    return render(request,"home.html")

#insert
def insert_view(request):
    context={}
    context['form']=StaffForm()
    return render(request,"insert_view.html",context)
def displayStaffInput(request):
    return render(request,'staff_entry.html')
def process_Staff_entry(request):
    if request.method== 'POST':
        staffid_inp=int(request.POST.get('staffid'))
        staffname_inp=request.POST.get('staffname')
        collegename_inp=request.POST.get('collegename')
        Department_inp=request.POST.get('Department')
        Designation_inp=request.POST.get('Designation')
        ob=StaffMaster(staffid=staffid_inp,staffname=staffname_inp,collegename=collegename_inp,Department=Department_inp,Designation=Designation_inp)
        ob.save()
        return render(request,'retrive.html')
    else:
        return HttpResponse("invalid request method...")
# delete
def delete_Staff(request):
    allst=StaffMaster.objects.all().values()
    temp=loader.get_template("delete_staff.html")
    context={
        'data':allst,
        }
    return HttpResponse(temp.render(context,request))

def display_staff(request):
    allstaff=StaffMaster.objects.all().values()
    temp=loader.get_template('all_staff.html')
    context={
        'data':allstaff,
        }
    return HttpResponse(temp.render(context,request))
def homeDisplay(request):
    return render(request,"home.html")
def delete1(request,pk):
    StaffMaster.objects.filter(id=pk).delete()
    return render(request,"retrive.html")


def search_view(request):
    if request.method == 'GET':
        form = SearchForm(request.GET)
        if form.is_valid():
            query = form.cleaned_data.get('query')
            results = StaffMaster.objects.filter(staffid=query)  
        else:
            results = None
    else:
        form = SearchForm()
        results = None
    
    return render(request, 'search_results.html', {'form': form, 'results': results})


def edit_staff(request, batch_id):
    staff= get_object_or_404(StaffMaster,id=pk)
    if request.method == 'POST':
        form = StaffForm(request.POST, instance=staff)
        if form.is_valid():
            form.save()
            return redirect('staff_detail', pk=pk)
    else:
        form = StaffForm(instance=staff)
    
    return render(request, 'edit_staff.html', {'form': form})

def staff_detail(request, pk):
    batch = get_object_or_404(StaffMaster, id=pk)
    return render(request, 'staff_detail.html', {'staff': staff})
def Staffmaster_details(request):
    allstaff=StaffMaster.objects.all().values()
    temp=loader.get_template('staffmaster.html')
    context={
        'data':allstaff
        }
    
    return HttpResponse(temp.render(context,request))
  



    
